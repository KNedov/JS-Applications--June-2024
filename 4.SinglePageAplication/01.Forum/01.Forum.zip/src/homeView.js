export function onHome() {
    const cancelBtn=document.querySelector('form .cancel')
    cancelBtn.addEventListener('click',onCancel)
    function onCancel(e) {
        debugger
    }
}