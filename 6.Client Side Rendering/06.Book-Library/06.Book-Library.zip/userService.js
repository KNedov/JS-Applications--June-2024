import{api} from "./src/utils/api.js"
import{userHelper} from "./userHelper.js"

const userEndpoints={
    login:"TODO",
    register:"TODO",
    Logout:"TODO"
}
                            // TODO
async function register(email,username,password) {
    const data= await api.post(userEndpoints.register,{email,username,password})
    userHelper.setUserData(data)
}
                        // TODO
async function login(emai,password) {
    const data=await api.post(userEndpoints.login,{emai,password})
    userHelper.setUserData(data)
}

async function Logout() {
    await api.get(userEndpoints.Logout)
    userHelper.removeUserData()
}
export const userService={
    register,
    login,
    Logout
}