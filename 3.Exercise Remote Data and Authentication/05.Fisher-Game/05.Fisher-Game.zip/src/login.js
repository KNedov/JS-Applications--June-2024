if (!sessionStorage.accessToken) {
  document.querySelector('#user').remove()
} else {
  document.querySelector('#guest').remove()
  document.querySelector('header span').textContent = sessionStorage.email;
}

let loginForm = document.querySelector('form');
loginForm.addEventListener('submit', logIn)

function logIn(event){
  try {
    event.preventDefault();
    let form = new FormData(loginForm);
    let email =  form.get('email');
    let password =  form.get('password');
    if (email===""||password==="") {
      throw new Error("field cannot be empty")
    }else{
      getLoginInfo(email,password)
     
    }
  } catch (error) {
    alert(error.message)
  }
 
}

async function getLoginInfo(email,password){
  try {
    let response = await fetch('http://localhost:3030/users/login',
      {method:'POST',
        headers:{"content-type":"application/json"},
        body: JSON.stringify({ email, password })
      }
    )
    if (response.status!==200) {
      throw new Error("You have entered an invalid email or password")
    }else{
      let data = await response.json()
      sessionStorage.setItem('accessToken', data.accessToken)
        sessionStorage.setItem('email', data.email)
        sessionStorage.setItem('_id', data._id)
        window.location = './index.html';
    }
   
    
  } catch (error) {
    alert(error.message)
  }
}
